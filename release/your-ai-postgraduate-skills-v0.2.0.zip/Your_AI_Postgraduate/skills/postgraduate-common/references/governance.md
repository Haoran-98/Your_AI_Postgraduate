# Governance

- Name every domain vault `Postgraduate_<EnglishDomainSlug>`.
- Use English ASCII slugs for generated folders and files; source-language titles may remain in note content.
- Keep domains independent. Do not create a global `Postgraduate_Common` vault.
- Before every new research task, apply `researcher-assignment-policy.md` and persist the assignment decision before literature work.
- Embed causal methods inside each domain vault and connect them with domain-specific causal bridges.
- Preserve `.raw/` sources. Write synthesized durable knowledge under `wiki/`.
- Read `wiki/index.md` and `wiki/hot.md` before meaningful changes.
- Update `wiki/index.md`, `wiki/hot.md`, and `wiki/log.md` after meaningful changes.
- After a substantial completed research pass, regenerate the knowledge profile so acquired knowledge, source coverage, and current task fit remain visible.
- Prefer official scholarly pages and record why important sources were included or excluded.
- Never paste private drafts or unpublished idea details into public searches without authorization.
- Never revert unrelated user changes in a dirty worktree.
